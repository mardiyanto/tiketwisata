
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>KRS STMIK PRINGSEWU</title>
<link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
<link rel="stylesheet" href="sys/lib/css/reset.css" type="text/css" media="screen, projection" />
<link rel="stylesheet" href="sys/lib/css/defaults.css" type="text/css" media="screen, projection" />
<link rel="stylesheet" href="sys/style.css" type="text/css" media="screen, projection" />
<link rel='stylesheet' id='dws_bootstrap-css'  href='sys/bootstrap.css' type='text/css' media='all' />
<link rel='stylesheet' id='dws_shortcodes-css'  href='sys/lib/shortcodes/css/shortcodes.css' type='text/css' media='all' />
<link rel='stylesheet' id='slideshow-css'  href='sys/lib/css/slideshow.css' type='text/css' media='all' />
<link rel='stylesheet' id='wordpress-popular-posts-css'  href='sys/lib/css/wpp.css' type='text/css' media='all' />
<script type='text/javascript' src='sys/lib/js/jquery.mobilemenu.js'></script>
<script type='text/javascript' src='sys/lib/js/jquery.js'></script>
<script type='text/javascript' src='sys/lib/js/jquery-migrate.min.js'></script>
<script type='text/javascript' src='sys/lib/shortcodes/js/bootstrap.js'></script>
<!-- Featured Posts -->
<script src="sys/js/jquery-1.4.4.js" type="text/javascript"></script>
<script src="sys/js/jquery.cycle.all.js" type="text/javascript"></script>

<link rel="Shortcut Icon" href="images/faticon.ico"  type="image/x-icon" />
</head>
<body class="home blog page-builder">
<div id="container">
    <div class="clearfix">
        			<div class="menu-primary-container">
					<ul id="menu-atas" class="menus menu-primary">
<li><a href="index.php">Hubungi Kami </a></li>
</ul></div>           <!--.primary menu--> 	
                


    </div>
	<div id="header">
    
        <div class="logo">
         <img src="sys/images/header-bg.png">
            
        </div><!-- .logo -->

        <div class="header-right">
 
        </div><!-- .header-right -->
        
    </div><!-- #header -->
    
	    <div class="clearfix">
            			<div class="menu-secondary-container">
						<ul id="menu-bawah" class="menus menu-secondary">
						<li><a href="index.aspx">Beranda </a></li>
						  
<li ><a href="?l=lihat&aksi=profil&id_p=4" >Profil Kampus</a>
	<ul>
<li><a href="?l=lihat&aksi=profil&id_p=4">Sejarah Kampus</a></li>
 <li> <a href="index.php?l=lihat&aksi=kontak">Kontak Kami</a></li>
 <li  ><a href="?l=lihat&aksi=carabayar">Visi Misi</a></li>
 <li><a href="?l=lihat&aksi=profil&id_p=2">Struktur Pimpinan</a></li>
	</ul>
</li>
<li><a href="info.aspx">Informasi</a></li>
 <li><a href='index.php?l=lihat&aksi=login' class="off">Pengumuman Kampus</a></li>

</ul>
		</div>
                      <!--.primary menu--> 	
                    

    </div>		



   <div id="main">
        <div id="content"> 	
 <?php include "kanan.php"; ?>		
						
						</div><!-- #content -->
<!--bagian kiri-->
         
    	<?php include "kiri.php"; ?>
<!--bagian bawah-->
    </div><!-- #main -->

    <div id="footer">
    
        <div id="copyrights">
            Copyright, Akabest<a href="index.php"> 2015</a>, Networks All Rights Reserved.</div>
    </div><!-- #footer -->
    
</div><!-- #container -->
</body>
</html>


