  <ul class="sidebar-menu">
  <li>
              <a href='index.php?aksi=home'>
                <i class='fa fa-dashboard'></i> <span>Dashboard</span> 
              </a> 
 </li>
 <li class='treeview'>
               <a href='#'>
                 <i class='fa fa-cog'></i>
                 <span>PENGATURAN</span>
               </a>
               <ul class='treeview-menu'>
                <li><a href='index.php?aksi=profil'><i class='fa fa-arrows-h'></i>Profil</a></li>
                <li><a href='index.php?aksi=admin'><i class='fa fa-arrows-h'></i>Admin</a></li>
               </ul>
 </li>
 <li class='treeview'>
               <a href='#'>
                 <i class='fa fa-credit-card'></i>
                 <span>BOOKING</span>
               </a>
               <ul class='treeview-menu'>
                <li><a href='index.php?aksi=tiket'><i class='fa fa-arrows-h'></i>Tiket</a></li>
                <li><a href='index.php?aksi=pembayaran'><i class='fa fa-arrows-h'></i>pembayaran</a></li>
                <li><a href='index.php?aksi=booking'><i class='fa fa-arrows-h'></i>booking</a></li>
                <li><a href='index.php?aksi=konfirmasi'><i class='fa fa-arrows-h'></i>konformasi</a></li>
                <li><a href='index.php?aksi=pengunjung'><i class='fa fa-arrows-h'></i>pengunjung</a></li>
               </ul>
 </li>                 
      <li>      
      <a href="logout.php">
                  <i class="fa fa-sign-out"></i> <span>LOGOUT</span>
                </a>
              </li>
</ul>